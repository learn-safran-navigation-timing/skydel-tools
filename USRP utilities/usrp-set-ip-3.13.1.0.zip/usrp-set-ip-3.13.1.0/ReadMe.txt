Execute the batch file "usrp_set_ip.bat" to change the IP address at Port 1 of the X300 or X310.

Edit the batch file if you need to change the current (DEVICE_ADDR_SRC) IP address and the new (DEVICE_ADDR_DST) IP Address.
Power-cycle is required after the command for changes to take effect.
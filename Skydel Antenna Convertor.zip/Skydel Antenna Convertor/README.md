# Antenna pattern convertor
Convert antenna .ant file to .csv or viceversa plus 3D view on UI or html link

# Python installation:
Make sure you have a python from version 3.8 or download the latest python version from https://www.python.org/downloads/.

# Open a terminal and ckeck your python version:
$ python --version

# Packages installation:
$ pip install -r requirements.txt

# Run Antenna Convertor script
$ python main.py

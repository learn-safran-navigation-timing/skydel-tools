1. Python installation:
Make sure you have a python from version 3.8 or download the latest python version from https://www.python.org/downloads/

2. Open a terminal and check your python version:
$ python --version

3. Navigate to this folder in the terminal using the following command:
$ cd your\folder\UBX Converter

5. Run the python script:
$ python Ublox_Ui.py

